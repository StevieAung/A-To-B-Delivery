<?php
include __DIR__."/middleware/auth.php";
include '../Database/db.php';

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');

$stmt = $conn->prepare("SELECT status, COUNT(*) cnt FROM delivery_requests WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY status");
$stmt->bind_param("ss",$from,$to);
$stmt->execute();
$res = $stmt->get_result();
$map = ['pending'=>0,'delivered'=>0,'cancelled'=>0];
while($row=$res->fetch_assoc()){ $map[$row['status']] = (int)$row['cnt']; }
$total = array_sum($map);
?>
<?php include __DIR__."/includes/head.php"; ?>
<?php include __DIR__."/includes/sidebar.php"; ?>
<main>
<?php include __DIR__."/includes/topbar.php"; ?>

<div class="card p-3">
  <form class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label">From</label><input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>"></div>
    <div class="col-md-3"><label class="form-label">To</label><input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>"></div>
    <div class="col-auto"><button class="btn btn-primary"><i class="fa fa-filter me-1"></i>Apply</button></div>
  </form>
</div>

<div class="row g-4 mt-3">
  <div class="col-md-3"><div class="card p-3 text-center"><h6>📦 Total</h6><h3><?= $total ?></h3></div></div>
  <div class="col-md-3"><div class="card p-3 text-center"><h6>✅ Delivered</h6><h3><?= $map['delivered'] ?></h3></div></div>
  <div class="col-md-3"><div class="card p-3 text-center"><h6>⏳ Pending</h6><h3><?= $map['pending'] ?></h3></div></div>
  <div class="col-md-3"><div class="card p-3 text-center"><h6>🗑 Cancelled</h6><h3><?= $map['cancelled'] ?></h3></div></div>
</div>

<div class="card p-3 mt-3">
  <h5 class="text-primary mb-2">📊 Breakdown</h5>
  <div class="chart-container"><canvas id="rep"></canvas></div>
</div>
</main>
<?php include __DIR__."/includes/footer.php"; ?>
<script>
new Chart(document.getElementById('rep').getContext('2d'),{
  type:'bar',
  data:{labels:['Delivered','Pending','Cancelled'],
        datasets:[{label:'Requests',data:[<?= $map['delivered'] ?>,<?= $map['pending'] ?>,<?= $map['cancelled'] ?>]}]},
  options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,ticks:{precision:0}}},plugins:{legend:{display:false}}}
});
</script>
