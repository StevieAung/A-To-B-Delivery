<?php
include __DIR__."/middleware/auth.php";
include '../Database/db.php';
include __DIR__."/middleware/csrf.php";
csrf_verify();

$allowed = ['all','pending','delivered','cancelled','in_transit','accepted','picked_up'];
$filter = $_GET['status'] ?? 'all';
if (!in_array($filter,$allowed)) $filter='all';

$sql = "SELECT d.request_id, u.first_name, u.last_name, d.pickup_location, d.delivery_location, d.status, d.created_at
        FROM delivery_requests d JOIN users u ON d.user_id=u.user_id";
if ($filter!=='all') $sql.=" WHERE d.status='". $conn->real_escape_string($filter) ."'";
$sql.=" ORDER BY d.created_at DESC LIMIT 200";
$rows = $conn->query($sql);

$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['request_id'], $_POST['new_status'])) {
  csrf_verify();
  $rid = (int)$_POST['request_id'];
  $new = $_POST['new_status'];
  if (in_array($new,$allowed) && $new!=='all') {
    $stmt = $conn->prepare("UPDATE delivery_requests SET status=? WHERE request_id=?");
    $stmt->bind_param("si",$new,$rid);
    $stmt->execute();
    $msg="Updated #$rid to ".htmlspecialchars($new);
    header("Location: manage_deliveries.php?status=".urlencode($filter)."&msg=".urlencode($msg));
    exit;
  }
}
?>
<?php include __DIR__."/includes/head.php"; ?>
<?php include __DIR__."/includes/sidebar.php"; ?>
<main>
<?php include __DIR__."/includes/topbar.php"; ?>

<?php if(isset($_GET['msg'])): ?><div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div><?php endif; ?>

<div class="card p-3">
  <form class="d-flex align-items-center gap-2">
    <label class="form-label mb-0">Status:</label>
    <select name="status" class="form-select" style="max-width:220px" onchange="this.form.submit()">
      <option value="all" <?= $filter==='all'?'selected':'' ?>>All</option>
      <?php foreach($allowed as $s): if($s==='all') continue; ?>
        <option value="<?= $s ?>" <?= $filter===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button class="btn btn-primary">Apply</button></noscript>
  </form>
</div>

<div class="card p-3 mt-3">
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead class="table-light"><tr><th>ID</th><th>Sender</th><th>Pickup</th><th>Drop</th><th>Status</th><th>Requested</th><th>Action</th></tr></thead>
      <tbody>
      <?php if($rows && $rows->num_rows): while($r=$rows->fetch_assoc()): ?>
        <tr>
          <td>#<?= $r['request_id'] ?></td>
          <td><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?></td>
          <td><?= htmlspecialchars($r['pickup_location']) ?></td>
          <td><?= htmlspecialchars($r['delivery_location']) ?></td>
          <td><span class="badge <?= $r['status']=='pending'?'bg-warning':($r['status']=='delivered'?'bg-success':'bg-secondary') ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span></td>
          <td><?= date("M d, Y H:i", strtotime($r['created_at'])) ?></td>
          <td>
            <form method="post" class="d-flex gap-2">
              <?php csrf_input(); ?>
              <input type="hidden" name="request_id" value="<?= (int)$r['request_id'] ?>">
              <select name="new_status" class="form-select form-select-sm" style="max-width:160px">
                <?php foreach($allowed as $s){ if($s==='all') continue; ?>
                  <option value="<?= $s ?>" <?= $s===$r['status']?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                <?php } ?>
              </select>
              <button class="btn btn-sm btn-primary"><i class="fa fa-check"></i></button>
            </form>
          </td>
        </tr>
      <?php endwhile; else: ?>
        <tr><td colspan="7" class="text-center text-muted">No deliveries found</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</main>
<?php include __DIR__."/includes/footer.php"; ?>
